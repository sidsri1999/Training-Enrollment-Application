package project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowData extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<br/><h1 align='center'>Training Enrollment Application<h1><br/><br/>");
		out.print("<html><body><table style='border: 1px solid black;border-collapse: collapse;'><tr><th>Training Id</th><th>Training Name</th><th>Availabale Seats</th><th>Enroll</th></tr>");
		try {
			Connection c = DataBaseCon.getConnection();
			PreparedStatement ps = c.prepareStatement("SELECT * FROM Training");
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				out.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getInt(3)+"</td><td><a href='Output?Id="+rs.getInt(1)+"&Seats="+rs.getInt(3)+"&Name="+rs.getString(2)+"'>Enroll</a></td></tr>");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		out.print("</table></body></html>");
		
	}

}
