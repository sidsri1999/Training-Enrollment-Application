package project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Output extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int Id = Integer.parseInt(request.getParameter("Id"));
		String Name = request.getParameter("Name");
		int Seats = Integer.parseInt(request.getParameter("Seats"));
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		if(Seats==0) {
			out.print("<br/><h1 align='center'>Training Enrollment Application</h1></br></br>");
			out.print("<h3 align='center'>Sorry! No Seats Are Available</h3>");
			out.print("<h5 align='center'><a href='index.html\'>Home Page</a></h5>");
		}else {
			out.print("<br/><h1 align='center'>Training Enrollment Application</h1></br></br>");
			out.print("<h3 align='center'>Hi you have succesfully enrolled for"+Name+"</h3>");
			out.print("<h5 align='center'><a href='index.html\'>Home Page</a></h5>");
			try {
				Connection c = DataBaseCon.getConnection();
				Statement stmt = c.createStatement();
				Seats=Seats-1;
				String query = "UPDATE Training SET AvailableSeats ='"+Seats+"' WHERE TrainingId = '"+Id+"'"; 
				ResultSet rs = stmt.executeQuery(query);
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	}
}
